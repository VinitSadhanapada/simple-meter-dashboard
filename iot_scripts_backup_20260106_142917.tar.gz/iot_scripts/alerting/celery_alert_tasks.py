"""
celery_alert_tasks.py
Celery task for processing meter alerts and writing events to Redis with expiry.
Includes a function to fetch recent alert events for visualization.
"""

import os
import redis
from datetime import datetime, timedelta
from celery import shared_task
from .alert_monitor_addon import PARAMETERS, check_alert
import json

# Redis config (edit as needed)
# Use short timeouts so web requests don't block for a long time when Redis is unreachable.
REDIS_URL = os.environ.get("REDIS_URL", "redis://localhost:6379/0")
# Set sensible timeouts (seconds) for connect and read operations. These keep the web UI responsive
# when Redis is down or unreachable from the container.
_REDIS_CONNECT_TIMEOUT = float(os.environ.get('REDIS_CONNECT_TIMEOUT', '2.0'))
_REDIS_SOCKET_TIMEOUT = float(os.environ.get('REDIS_SOCKET_TIMEOUT', '2.0'))
try:
    r = redis.Redis.from_url(
        REDIS_URL,
        decode_responses=True,
        socket_connect_timeout=_REDIS_CONNECT_TIMEOUT,
        socket_timeout=_REDIS_SOCKET_TIMEOUT,
    )
except Exception:
    # Fallback to a basic client; actual operations will be wrapped with try/except below.
    r = redis.Redis.from_url(REDIS_URL, decode_responses=True)

# How long to keep alert events (seconds). Also used as the minimum episode duration for file logging.
ALERT_EVENT_TTL = int(os.environ.get('ALERT_EVENT_TTL', '300'))  # seconds to retain recent events for API consumption
# How long an alert condition must persist before we emit an event
ALERT_PERSISTENCE_SECONDS = int(os.environ.get('ALERT_PERSISTENCE_SECONDS', '10'))  # 10s for testing

# Redis keys helper
def k_last_seen(device_id, param):
    return f"alert:last_seen:{device_id}:{param}"

def k_last_state(device_id, param):
    return f"alert:last_state:{device_id}:{param}"

def k_alert_start(device_id, param):
    return f"alert:start:{device_id}:{param}"

def k_alert_logged(device_id, param):
    return f"alert:logged:{device_id}:{param}"

# File log path (absolute) under iot_scripts
ALERT_LOG_PATH = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'alerts.log'))

def _append_alert_log(device_id, param, alert_type, start_iso, end_iso, duration_s, value):
    """Append a single line to alerts.log when an episode qualifies for logging."""
    try:
        line = (
            f"[{end_iso}] device={device_id} param={param} episode={alert_type} "
            f"duration={int(duration_s)}s start={start_iso} end={end_iso} value={value}\n"
        )
        with open(ALERT_LOG_PATH, 'a') as f:
            f.write(line)
    except Exception:
        # File logging must not interfere with processing
        pass

def _parse_state(raw: str | None):
    """Backward-compatible state parser.
    Returns (phase, alert_name) where phase in {none, ok, pending, alert}.
    Old style states (like 'v_r_ph_low') are treated as 'alert:<name>'.
    """
    if not raw:
        return ("none", None)
    if raw == "ok":
        return ("ok", None)
    if raw.startswith("pending:"):
        return ("pending", raw.split(":", 1)[1])
    if raw.startswith("alert:"):
        return ("alert", raw.split(":", 1)[1])
    # Backward compatibility: treat bare alert name as active alert
    return ("alert", raw)


@shared_task
def process_meter_alert(device_id, meter_data):
    """
    Celery task: Check parameters and write a SINGLE alert event per fault episode:
    - Emit on OK -> Fault transition only after persistence window.
    - Suppress duplicates while in the same Fault.
    - Emit a 'recovered' event on Fault -> OK transition.
    """
    now_dt = datetime.utcnow()
    now_iso = now_dt.isoformat()
    for param in PARAMETERS:
        value = meter_data.get(param)
        alert_type = check_alert(param, value)
        try:
            state_key = k_last_state(device_id, param)
            seen_key = k_last_seen(device_id, param)
            prev_raw = r.get(state_key)
            prev_phase, prev_name = _parse_state(prev_raw)

            if alert_type:
                # Fault observed now
                if prev_phase in ("none", "ok"):
                    # Start a new pending episode
                    r.set(state_key, f"pending:{alert_type}")
                    r.set(seen_key, now_iso)
                elif prev_phase == "pending":
                    if prev_name != alert_type:
                        # Different alert while pending: reset episode
                        r.set(state_key, f"pending:{alert_type}")
                        r.set(seen_key, now_iso)
                    else:
                        # Same pending: check if persisted long enough
                        first_seen = r.get(seen_key)
                        try:
                            started = datetime.fromisoformat(first_seen) if first_seen else now_dt
                        except Exception:
                            started = now_dt
                        if (now_dt - started).total_seconds() >= ALERT_PERSISTENCE_SECONDS:
                            # Transition to active alert and emit exactly once
                            event = {
                                "device_id": device_id,
                                "param": param,
                                "alert_type": alert_type,
                                "value": value,
                                "timestamp": now_iso
                            }
                            key = f"alert_events:{device_id}"
                            r.rpush(key, json.dumps(event))
                            r.expire(key, ALERT_EVENT_TTL)
                            r.set(state_key, f"alert:{alert_type}")
                            r.delete(seen_key)
                            # Mark start of active episode for file logging
                            r.set(k_alert_start(device_id, param), now_iso)
                            r.delete(k_alert_logged(device_id, param))
                elif prev_phase == "alert":
                    if prev_name != alert_type:
                        # New/different alert while another is active -> start a new pending episode
                        r.set(state_key, f"pending:{alert_type}")
                        r.set(seen_key, now_iso)
                    else:
                        # Same alert remains active -> if not logged yet and duration >= TTL, log once
                        try:
                            start_iso = r.get(k_alert_start(device_id, param))
                            logged = r.get(k_alert_logged(device_id, param))
                            if start_iso and not logged:
                                try:
                                    start_dt = datetime.fromisoformat(start_iso)
                                except Exception:
                                    start_dt = now_dt
                                duration = (now_dt - start_dt).total_seconds()
                                if duration >= ALERT_EVENT_TTL:
                                    _append_alert_log(device_id, param, alert_type, start_iso, now_iso, duration, value)
                                    r.set(k_alert_logged(device_id, param), '1')
                        except Exception:
                            pass
            else:
                # OK observed now
                if prev_phase == "alert":
                    # Emit a recovery event when clearing an active alert
                    event = {
                        "device_id": device_id,
                        "param": param,
                        "alert_type": "recovered",
                        "value": value,
                        "timestamp": now_iso
                    }
                    key = f"alert_events:{device_id}"
                    r.rpush(key, json.dumps(event))
                    r.expire(key, ALERT_EVENT_TTL)
                    # If not yet logged and episode exceeded TTL, log at recovery
                    try:
                        start_iso = r.get(k_alert_start(device_id, param))
                        logged = r.get(k_alert_logged(device_id, param))
                        if start_iso and not logged:
                            try:
                                start_dt = datetime.fromisoformat(start_iso)
                            except Exception:
                                start_dt = now_dt
                            duration = (now_dt - start_dt).total_seconds()
                            if duration >= ALERT_EVENT_TTL:
                                _append_alert_log(device_id, param, prev_name or 'alert', start_iso, now_iso, duration, value)
                    except Exception:
                        pass
                # Reset state to ok and clear any timers
                r.set(state_key, 'ok')
                r.delete(seen_key)
                r.delete(k_alert_start(device_id, param))
                r.delete(k_alert_logged(device_id, param))
        except Exception:
            # Never let alert processing break ingestion; swallow errors per param
            continue


def fetch_recent_alert_events(device_id=None, limit=100):
    """
    Fetch recent alert events from Redis for a device (or all devices).
    Returns a list of dicts sorted by timestamp (most recent last).
    """
    events = []
    try:
        if device_id:
            keys = [f"alert_events:{device_id}"]
        else:
            # Scan all device keys (non-blocking generator). Wrap in try/except in case Redis is unreachable.
            keys = list(r.scan_iter("alert_events:*"))
        for key in keys:
            try:
                raw_events = r.lrange(key, -limit, -1)
            except Exception:
                # If a particular key cannot be read, skip it.
                continue
            for raw in raw_events:
                try:
                    event = json.loads(raw)
                    events.append(event)
                except Exception:
                    continue
    except Exception:
        # Any Redis/connectivity error should not block the view; return empty events.
        return []
    # Sort by timestamp
    events.sort(key=lambda e: e["timestamp"])
    return events

# Example: format for table/plot
# [ {"device_id": ..., "param": ..., "alert_type": ..., "value": ..., "timestamp": ...}, ... ]
