import time
import requests

# Configuration
BASE_URL = "http://localhost:8000"  # Change if needed
ALERTS_API = f"{BASE_URL}/api/alerts/"
SET_FAILURE_API = f"{BASE_URL}/api/set_failure_mode/"
METER_NAME = "testKK1"  # Change to a real meter name in your DB
FAILURE_MODE = "overcurrent"
NORMAL_MODE = None


def set_failure_mode(meter_name, mode):
    resp = requests.post(SET_FAILURE_API, json={"meter_name": meter_name, "mode": mode})
    print(f"Set failure mode {mode} for {meter_name}: {resp.json()}")
    return resp

def get_alerts():
    resp = requests.get(ALERTS_API)
    print(f"Alerts: {resp.json()}")
    return resp.json()

def test_alert_cycle():
    print("--- Starting alert test cycle ---")
    # 1. Set failure mode
    set_failure_mode(METER_NAME, FAILURE_MODE)
    time.sleep(2)
    # 2. Check for alert
    alerts = get_alerts()
    assert any(ev['device_id'] == METER_NAME and ev['alert_type'] for ev in alerts.get('events', [])), "Alert not found after failure mode set!"
    print("Alert detected as expected.")
    # 3. Wait for expiry
    print("Waiting for alert expiry...")
    time.sleep(6)
    alerts = get_alerts()
    assert not any(ev['device_id'] == METER_NAME and ev['alert_type'] for ev in alerts.get('events', [])), "Alert did not expire as expected!"
    print("Alert expired as expected.")
    # 4. Set back to normal
    set_failure_mode(METER_NAME, NORMAL_MODE)
    print("--- Alert test cycle complete ---")

if __name__ == "__main__":
    test_alert_cycle()
