"""
alert_monitor_addon.py
Parameters and utility functions for alert monitoring.
To be used with Celery and Redis for alert event processing.
"""

# Example: which parameters to monitor and their thresholds
PARAMETERS = {
    'v_r_ph': {'min': 210, 'max': 250, 'label': 'Voltage R'},
    'v_y_ph': {'min': 210, 'max': 250, 'label': 'Voltage Y'},
    'v_b_ph': {'min': 210, 'max': 250, 'label': 'Voltage B'},
    'a_r_ph': {'max': 10, 'label': 'Current R'},
    'a_y_ph': {'max': 10, 'label': 'Current Y'},
    'a_b_ph': {'max': 10, 'label': 'Current B'},
    'frequency': {'min': 49, 'max': 51, 'label': 'Frequency'},
    # Add more as needed
}

# Utility function to check alert condition for a parameter
def check_alert(param, value):
    cfg = PARAMETERS.get(param)
    if cfg is None:
        return None
    try:
        value = float(value)
    except Exception:
        return None
    if 'min' in cfg and value < cfg['min']:
        return f"{param}_low"
    if 'max' in cfg and value > cfg['max']:
        return f"{param}_high"
    return None
