# Alerts with Redis + Celery

This guide explains how the Simple Meter Dashboard publishes and displays alerts using Redis and Celery, and how to run, test, and troubleshoot it on a Raspberry Pi.

## Overview

- Ingestion (`iot_scripts/mqtt_to_db_ingest.py`) inserts meter readings into PostgreSQL and enqueues an async alert task per reading.
- Celery worker consumes tasks and evaluates alert conditions. It writes short-lived alert events to Redis with a TTL.
- Web API `/api/alerts/` reads those events from Redis. The human UI at `/alerts/` shows them nicely, and the latest page highlights devices with active alerts.
- We no longer use `current_alerts.json`; file-based alerts were deprecated in favor of the Redis stream.

### Alert rules

- See `iot_scripts/alerting/alert_monitor_addon.py` (PARAMETERS with min/max).
- Only one event is emitted per fault episode:
  - OK → Fault triggers a single alert event after a persistence window (default 10s).
  - Fault → OK triggers a single `recovered` event.
  - While the same fault persists, no duplicates are emitted.
- Configure persistence duration via `ALERT_PERSISTENCE_SECONDS` env var (e.g., `3` for quicker testing).

## Prerequisites

- Python virtualenv set up at `venv/` in repo root.
- Redis server installed and running on localhost (default RPi package works):
  - `sudo systemctl status redis-server` should show Active: running
- PostgreSQL reachable using settings in `meter_dashboard/meter_dashboard/settings.py` (or `iot_scripts/config.json`).

## Start the system

1) Start Redis (if not already):

```bash
sudo systemctl start redis-server
sudo systemctl status redis-server
```

2) Activate venv and start the Celery worker from the repo root:

```bash
cd /home/pi/Desktop/simple-meter-dashboard
source venv/bin/activate
# Optional: speed up demo
export ALERT_PERSISTENCE_SECONDS=3
celery -A meter_dashboard worker -l info
```

- You should see the worker connect to `redis://127.0.0.1:6379/0` and show `ready`.

3) Run the ingestion script in a new terminal:

```bash
cd /home/pi/Desktop/simple-meter-dashboard/iot_scripts
source ../venv/bin/activate
python3 mqtt_to_db_ingest.py
```

- You should see lines like:
  - `[INGEST] inserting meter=… device_id=… time=…`
  - `[alert-dispatch] Enqueued via celery_app -> broker=redis://127.0.0.1:6379/0`

## View alerts

- API JSON: `http://<pi-ip>:8000/api/alerts/`
- UI page: `http://<pi-ip>:8000/alerts/`
- Latest Readings page highlights rows whose device_id currently has any active alert.

## How it works (components)

- Dispatcher: `iot_scripts/alerting/dispatcher.py`
  - Ensures `meter_dashboard` app is importable and sends the task (`send_task`) to the configured Celery broker.
- Celery app: `meter_dashboard/meter_dashboard/celery.py`
  - Loads Django settings and registers tasks.
- Task: `iot_scripts/alerting/celery_alert_tasks.py`
  - Enforces the persistence window and writes per-device event lists in Redis (`alert_events:<device_id>`), TTL 5 minutes.
- API: `meter_dashboard/meter_dashboard/api_views.py::api_alert_events`
  - Reads events from Redis using `fetch_recent_alert_events`.
- UI: `meter_dashboard/meter_readings/templates/alerts/alerts_dashboard.html` rendered by `alerts_dashboard` view.

## Troubleshooting

- Worker can’t import meter_dashboard:
  - Start it from repo root (not inside `meter_dashboard/`), ensure venv active.
- Ingest shows `Connection refused (broker=…)`:
  - Ensure Redis is running and the Celery worker is up.
- `/api/alerts/` empty:
  - Wait longer than `ALERT_PERSISTENCE_SECONDS` while a fault persists.
  - Confirm worker logs show tasks received.
- Reset state for a clean test:

```bash
source venv/bin/activate
python - <<'PY'
import redis
r=redis.Redis(host='127.0.0.1',port=6379,db=0,decode_responses=True)
for p in ('alert_events:*','alert:last_state:*','alert:last_seen:*'):
  for k in r.scan_iter(p):
    r.delete(k)
print('cleared')
PY
```

## Configuration knobs

- `ALERT_PERSISTENCE_SECONDS` (env): seconds a fault must persist before emitting.
- `CELERY_BROKER_URL` (Django settings): broker URL, default `redis://127.0.0.1:6379/0`.
- Alert thresholds: edit `PARAMETERS` in `alert_monitor_addon.py`.

## Migration notes (file alerts removed)

- The legacy `current_alerts.json` and `alerts.log` flow is deprecated.
- `iot_scripts/alerting/state_alerts.py::check_and_log_alerts` is now a no-op.
- `meter_readings/latest_readings` page now derives active alerts from Redis events (not from the JSON file).

