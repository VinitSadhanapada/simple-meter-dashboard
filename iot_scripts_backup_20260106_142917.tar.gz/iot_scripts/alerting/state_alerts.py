"""
state_alerts.py (deprecated)
This legacy module wrote file-based current_alerts.json and alerts.log.
The system now uses Redis/Celery events for alerts. This file remains for reference.
"""
from __future__ import annotations
import os
import json
from datetime import datetime
from typing import Dict, Any, List


# Base directory is the iot_scripts folder (one level up from this file)
BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
ALERT_LOG_PATH = os.path.join(BASE_DIR, 'alerts.log')
ALERT_STATE_PATH = os.path.join(BASE_DIR, 'current_alerts.json')


def check_and_log_alerts(meter_data: Dict[str, Any]) -> None:
    """
    Deprecated: no-op placeholder retained for backward compatibility if imported.
    """
    # Early exit: do nothing
    return
    alerts: List[str] = []
    # Simulated failure mode alerts
    mode = meter_data.get('failure_mode', 'none')
    if mode and mode != 'none':
        if mode == 'phase_loss':
            alerts.append('Simulated Phase Loss: All phases lost')
        elif mode == 'overcurrent':
            alerts.append('Simulated Overcurrent: Current exceeds safe limit')
        elif mode == 'bad_pf':
            alerts.append('Simulated Bad Power Factor: PF very low')
        elif mode == 'overvoltage':
            alerts.append('Simulated Overvoltage: Voltage exceeds safe limit')
        elif mode == 'reverse_power':
            alerts.append('Simulated Reverse Power: Power flow reversed')
        elif mode == 'freq_drift':
            alerts.append('Simulated Frequency Drift: Frequency out of range')
        else:
            alerts.append(f'Simulated Failure Mode: {mode}')

    # Real value-based alerts (original thresholds)
    for phase in ['v_r_ph', 'v_y_ph', 'v_b_ph']:
        v = meter_data.get(phase)
        if v is not None:
            try:
                v = float(v)
                if v > 250 or v < 210:
                    alerts.append(f"Voltage {phase.upper()} out of range: {v}V")
            except Exception:
                pass
    for phase in ['a_r_ph', 'a_y_ph', 'a_b_ph']:
        a = meter_data.get(phase)
        if a is not None:
            try:
                a = float(a)
                if a > 10:
                    alerts.append(f"Current {phase.upper()} high: {a}A")
            except Exception:
                pass
    freq = meter_data.get('frequency')
    if freq is not None:
        try:
            freq = float(freq)
            if freq < 49 or freq > 51:
                alerts.append(f"Frequency out of range: {freq}Hz")
        except Exception:
            pass

    meter_name = meter_data.get('meter_name', 'Unknown')
    now = datetime.now().strftime('%Y-%m-%d %H:%M:%S')

    # Read existing alerts state
    try:
        with open(ALERT_STATE_PATH, 'r') as f:
            state = json.load(f)
        if not isinstance(state.get('active_alerts'), dict):
            state['active_alerts'] = {}
    except Exception:
        state = {'active_alerts': {}, 'timestamp': now}

    if alerts:
        # Update this meter's alerts
        state['active_alerts'][meter_name] = alerts
        state['timestamp'] = now
        # Write to log
        try:
            with open(ALERT_LOG_PATH, 'a') as f:
                for alert in alerts:
                    f.write(f"[{now}] {meter_name}: {alert}\n")
        except Exception:
            pass
    else:
        # Remove this meter's alerts if none
        if meter_name in state['active_alerts']:
            del state['active_alerts'][meter_name]
        state['timestamp'] = now

    # Save updated state
    with open(ALERT_STATE_PATH, 'w') as f:
        json.dump(state, f)
