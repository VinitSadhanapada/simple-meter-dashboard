"""
dispatcher.py
Encapsulates alert pipeline dispatch so ingestion can remain simple.
Provides enqueue_alert_processing(device_key, meter_data) to push alert checks to Celery/Redis.
"""
from __future__ import annotations
import os
import sys
from typing import Any, Dict


def _ensure_django_settings_loaded() -> None:
    """Ensure Django settings and paths are initialized for standalone scripts."""
    # Prepare sys.path so 'meter_dashboard' and top-level packages are importable
    here = os.path.dirname(os.path.abspath(__file__))                # .../iot_scripts/alerting
    repo_root = os.path.abspath(os.path.join(here, '..', '..'))      # .../simple-meter-dashboard
    project_dir = os.path.join(repo_root, 'meter_dashboard')         # .../simple-meter-dashboard/meter_dashboard
    # Ensure both repo root and Django project dir are importable
    for p in (repo_root, project_dir):
        if p not in sys.path:
            sys.path.append(p)
    os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'meter_dashboard.settings')
    # Initialize Django once
    try:
        import django  # type: ignore
        if not getattr(_ensure_django_settings_loaded, "_did_setup", False):
            django.setup()  # type: ignore
            _ensure_django_settings_loaded._did_setup = True  # type: ignore[attr-defined]
    except Exception:
        # If Django isn't available, we'll still try best-effort Celery init below
        pass


def _ensure_celery_app() -> str | None:
    """Import the project's Celery app so shared_task binds to the configured app.
    Returns the broker URL if available.
    """
    try:
        # Importing meter_dashboard triggers __init__.py which loads celery app
        import meter_dashboard  # noqa: F401
        from celery import current_app  # type: ignore
        broker_url = getattr(current_app.conf, 'broker_url', None)
        return broker_url
    except Exception:
        # Try once more after ensuring project dir on path
        try:
            here = os.path.dirname(os.path.abspath(__file__))
            repo_root = os.path.abspath(os.path.join(here, '..', '..'))
            project_dir = os.path.join(repo_root, 'meter_dashboard')
            if project_dir not in sys.path:
                sys.path.append(project_dir)
            import meter_dashboard  # noqa: F401
            from celery import current_app  # type: ignore
            return getattr(current_app.conf, 'broker_url', None)
        except Exception:
            return None


def enqueue_alert_processing(device_key: str, meter_data: Dict[str, Any]) -> bool:
    """
    Dispatch alert evaluation to Celery. Returns True if enqueued, else False.
    device_key: prefer device_id; fallback to meter_name.
    """
    try:
        _ensure_django_settings_loaded()
        broker_url = _ensure_celery_app()
        # Prefer sending via the project's Celery app to ensure the configured broker is used
        try:
            from meter_dashboard.celery import app as celery_app  # type: ignore
        except Exception:
            # Build a Celery app from Django settings as a fallback
            try:
                from django.conf import settings as _dj_settings  # type: ignore
                from celery import Celery  # type: ignore
                celery_app = Celery('meter_dashboard')  # type: ignore
                broker_url = getattr(_dj_settings, 'CELERY_BROKER_URL', broker_url)
                if broker_url:
                    celery_app.conf.broker_url = broker_url  # type: ignore
            except Exception:
                celery_app = None  # type: ignore

        task_name = 'iot_scripts.alerting.celery_alert_tasks.process_meter_alert'
        if celery_app is not None:  # type: ignore
            celery_app.send_task(task_name, args=(str(device_key), meter_data))  # type: ignore
            print(f"[alert-dispatch] Enqueued via celery_app -> broker={getattr(celery_app.conf, 'broker_url', broker_url)}", flush=True)  # type: ignore
            return True

        # Fallback: call the task object's apply_async (may use default app if configured)
        try:
            from iot_scripts.alerting.celery_alert_tasks import process_meter_alert
        except Exception:
            from alerting.celcery_alert_tasks import process_meter_alert
        process_meter_alert.apply_async(args=(str(device_key), meter_data))
        if broker_url:
            print(f"[alert-dispatch] Enqueued alert task -> broker={broker_url}", flush=True)
        return True
    except Exception as e:
        broker = '(settings unavailable)'
        try:
            # Prefer Celery current_app broker when available
            from celery import current_app  # type: ignore
            broker = getattr(current_app.conf, 'broker_url', broker)
        except Exception:
            try:
                from django.conf import settings as _dj_settings  # type: ignore
                broker = getattr(_dj_settings, 'CELERY_BROKER_URL', broker)
            except Exception:
                pass
        print(f"[alert-dispatch] Failed to enqueue alert task: {e} (broker={broker})", flush=True)
        return False
