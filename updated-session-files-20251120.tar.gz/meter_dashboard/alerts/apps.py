from django.apps import AppConfig

class AlertsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'meter_dashboard.alerts'
    verbose_name = 'Meter Alerts'
