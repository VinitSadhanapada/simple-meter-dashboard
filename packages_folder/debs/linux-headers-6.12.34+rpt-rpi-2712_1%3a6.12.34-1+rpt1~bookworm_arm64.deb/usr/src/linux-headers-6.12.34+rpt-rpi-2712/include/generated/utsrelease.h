#define UTS_RELEASE "6.12.34+rpt-rpi-2712"
