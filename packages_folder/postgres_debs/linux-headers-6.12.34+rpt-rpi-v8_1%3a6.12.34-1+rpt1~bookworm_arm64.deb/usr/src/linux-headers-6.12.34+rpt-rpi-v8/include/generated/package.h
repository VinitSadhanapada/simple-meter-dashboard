#define LINUX_PACKAGE_ID " Debian 1:6.12.34-1+rpt1~bookworm"
