#define UTS_MACHINE		"aarch64"
#define LINUX_COMPILE_BY	"serge"
#define LINUX_COMPILE_HOST	"raspberrypi.com"
#define LINUX_COMPILER		"aarch64-linux-gnu-gcc-12 (Debian 12.2.0-14+deb12u1) 12.2.0, GNU ld (GNU Binutils for Debian) 2.40"
