#define UTS_VERSION "#1 SMP PREEMPT Debian 1:6.12.34-1+rpt1~bookworm (2025-06-26)"
